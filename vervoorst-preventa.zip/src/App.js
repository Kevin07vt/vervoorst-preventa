import React, { useState } from 'react';
import './App.css';

function App() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="container">
      <h1 className="title">Vervoorst</h1>
      <p className="subtitle">Lanzamiento exclusivo muy pronto</p>
      {!submitted ? (
        <form onSubmit={handleSubmit} className="form">
          <input
            type="email"
            placeholder="Tu correo electrónico"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <button type="submit">Avísame</button>
        </form>
      ) : (
        <p className="gracias">¡Gracias por unirte! Te avisaremos muy pronto.</p>
      )}
    </div>
  );
}

export default App;